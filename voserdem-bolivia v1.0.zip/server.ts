import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { Project, Donation, Message, BlogPost, Bulletin, Subscriber, CarouselSlide, LogoConfig } from './src/types.js';

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(process.cwd(), 'data-store.json');

// Midlewares
app.use(express.json());

// Initialize default data if file doesn't exist
const initialBlog: BlogPost[] = [
  {
    id: 'blog-1',
    title: 'Restauración activa en el Tunari: ¿Por qué plantamos Queñuas?',
    summary: 'La queñua (Polylepis) es un árbol nativo indispensable para recargar los acuíferos de Cochabamba. Descubre el impacto ecológico de nuestras jornadas en Chocaya.',
    content: 'En las alturas de la cordillera del Tunari, la erosión del suelo y la pérdida de cobertura vegetal nativa amenazan la seguridad hídrica de Cochabamba. El género Polylepis, popularmente conocido como Queñua, cumple un papel ecológico protagónico. Sus troncos retorcidos y su corteza laminada atrapan la niebla y la humedad del ambiente de montaña, infiltrando agua dulce directo en las vertientes subterráneas que alimentan el valle cochabambino.\n\nEn nuestras últimas campañas voluntarias de Ecocamp Chocaya, hemos plantado más de 400 nuevos brotes de queñua producidos en nuestro vivero forestal. El riego inicial y el cuidado orgánico de estas plántulas son cruciales durante el invierno andino. Invitamos a la comunidad de Cochabamba y a las escuelas a unirse a los talleres semanales donde aprendemos sobre la producción de compostaje y conservación de biodiversidad nativa.',
    image: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?auto=format&fit=crop&q=80&w=800',
    category: 'Ecología',
    author: 'Ing. René Mendoza, Coordinador Ecológico',
    date: '2026-05-15',
    readTime: '4 min',
    featured: true
  },
  {
    id: 'blog-2',
    title: 'Tejiendo lazos con nuestras abuelas en Cochabamba',
    summary: 'Nuestro taller semanal de costura creativa no solo genera hermosos bolsos reciclados, sino que reconstruye redes de autoestima y afecto filial en nuestras adultas mayores.',
    content: 'Cada día, a partir de las 9 de la mañana, el comedor central de VOSERDEM abre sus puertas para acoger a más de sesenta abuelitas de diversas zonas periurbanas de Cochabamba. Tras una comida diseñada con alta concentración proteica y vitaminas esenciales por nuestro equipo de nutricionistas, la sala se transforma.\n\nLas máquinas de coser y los hilos de colores se adueñan del espacio. Este año, inauguramos la línea de Costura Creativa Ecofamilia. Bajo la guía de voluntarias capacitadas en diseño de modas, nuestras queridas abuelitas transforman telas reutilizadas y retazos de jeans en espléndidos bolsos, estuches y manteles de cocina con detalles bordados a mano. Este espacio tiene un valor terapéutico incalculable: les ayuda con la motricidad fina, combate de raíz la soledad crónica de la vejez y les proporciona un ingreso digno del comercio sustentable.',
    image: 'https://images.unsplash.com/photo-1544027993-37dbfe43562a?auto=format&fit=crop&q=80&w=800',
    category: 'Adulto Mayor',
    author: 'Lic. Clara Salazar, Trabajo Social',
    date: '2026-05-28',
    readTime: '5 min',
    featured: false
  },
  {
    id: 'blog-3',
    title: 'La permacultura como motor de soberanía alimentaria urbana',
    summary: 'Implementamos con éxito 15 nuevos micro-huertos familiares en el Distrito 9. Consejos prácticos de cultivo orgánico urbano en tierras secas de Cochabamba.',
    content: 'El desarrollo sostenible empieza en el núcleo familiar. El constante aumento de precio en los alimentos básicos afecta de manera desproporcionada a las familias periurbanas del sur de Cochabamba. VOSERDEM, con su programa de Micro-Huertos Orgánicos, brinda una alternativa de autonomía nutricional real.\n\nEn la última capacitación comunitaria, enseñamos cómo preparar "camas de doble excavación" para retener la humedad en terrenos áridos, emplear acolchado de paja (mulch) para evitar la evaporación bajo el inclemente sol andino y fabricar biopreparados caseros a base de ajo, ají y cenizas para repeler plagas de forma no tóxica. Nos entusiasma ver la primera cosecha de lechugas moradas, tomates cherry andinos y acelgas gigantescas cultivados con el sudor de madres cochabambinas, reduciendo los gastos de canasta básica y garantizando alimentación 100% limpia sin pesticidas.',
    image: 'https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?auto=format&fit=crop&q=80&w=800',
    category: 'Comunidad',
    author: 'Est. Andrés Torrico, Agronomía',
    date: '2026-06-01',
    readTime: '3 min',
    featured: false
  }
];

const initialBulletins: Bulletin[] = [
  {
    id: 'bull-1',
    title: 'Boletín Informativo Otoño 2026 - Edición N° 12',
    summary: 'Revisión completa de las campañas de invierno en el Tunari, informe de raciones servidas en el comedor de abuelitas e inicio de la Escuela Eco para jóvenes.',
    publishDate: '2026-04-30',
    issueNumber: 'Año 12 - N° 1',
    downloadUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    image: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'bull-2',
    title: 'Memoria Ecológica de Chocaya - Edición Especial',
    summary: 'Edición exclusiva detallando las técnicas de filtración hídrica y reforestación de cuencas de cabecera de agua implementadas por los ingenieros de la UMSS y técnicos ecólogos bolivianos.',
    publishDate: '2025-11-15',
    issueNumber: 'N° Especial Viveros',
    downloadUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    image: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?auto=format&fit=crop&q=80&w=800'
  }
];

const initialProjects: Project[] = [
  {
    id: 'proj-1',
    title: 'Ecocamp Chocaya',
    description: 'Centro de restauración ecológica y educación ambiental en Bolivia. Aprendizaje activo sobre permacultura, reforestación y tecnologías ecológicas para jóvenes comunitarios.',
    category: 'Medio Ambiente',
    image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=800',
    goal: 15000,
    raised: 8450,
    location: 'Chocaya, Cochabamba, Bolivia',
    impact: 'Más de 500 árboles nativos plantados y 250 jóvenes capacitados anualmente.',
    details: 'El Ecocamp de Chocaya es una de nuestras joyas de restauración de ecosistemas. Enclavado en las faldas de la cordillera del Tunari, reforestamos tierras erosionadas y enseñamos a los escolares locales los secretos de la permacultura. Los fondos se utilizarán para ampliar el vivero de árboles autóctonos y mejorar los sistemas de riego por goteo.'
  },
  {
    id: 'proj-2',
    title: 'Las Abuelitas de VOSERDEM',
    description: 'Programa de asistencia social y de nutrición integral para abuelas vulnerables. Un refugio de acogida, talleres manuales y alimentación digna en Cochabamba.',
    category: 'Adulto Mayor',
    image: 'https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&q=80&w=800',
    goal: 10000,
    raised: 6200,
    location: 'Cochabamba Centro, Bolivia',
    impact: 'Alimentación diaria de alta calidad y talleres de salud mental para 60 adultas mayores en peligro de exclusión social.',
    details: 'Muchas adultas mayores en Cochabamba carecen de cobertura social o familiar. En VOSERDEM, las recibimos con los brazos abiertos. Este proyecto cubre almuerzos nutritivos calientes de lunes a viernes, chequeos médicos básicos, medicamentos esenciales y un taller de costura y artesanía que les devuelve el propósito y la autonomía.'
  },
  {
    id: 'proj-3',
    title: 'Micro-Huertos y Soberanía Alimentaria',
    description: 'Capacitación familiar en agricultura ecológica urbana. Construcción de camas de cultivo y manejo orgánico de plagas en zonas periurbanas de Cochabamba.',
    category: 'Desarrollo',
    image: 'https://images.unsplash.com/photo-1530595467537-0b5996c41f2d?auto=format&fit=crop&q=80&w=800',
    goal: 8000,
    raised: 3500,
    location: 'Distrito 9, Cochabamba, Bolivia',
    impact: '45 familias con sus propios huertos productivos activos, mejorando su alimentación y economía doméstica.',
    details: 'Buscamos empoderar a los barrios más desfavorecidos con herramientas prácticas para cultivar verduras frescas en poco espacio. Este proyecto provee de semillas orgánicas, fertilizante ecológico, tierra preparada y asesores que guían a cada familia en la siembra y cosecha de sus propios alimentos.'
  }
];

interface PillarItem {
  title: string;
  description: string;
  iconName: string;
}

interface AboutUsData {
  introSub: string;
  introTitle: string;
  introText: string;
  missionTitle: string;
  missionText: string;
  visionTitle: string;
  visionText: string;
  imageUrl: string;
  heroImageUrl?: string;
  pillars: PillarItem[];
}

interface DataStore {
  projects: Project[];
  donations: Donation[];
  messages: Message[];
  blog: BlogPost[];
  bulletins: Bulletin[];
  subscribers: Subscriber[];
  aboutUs?: AboutUsData;
  carouselSlides?: CarouselSlide[];
  logoConfig?: LogoConfig;
}

const initialAboutUs: AboutUsData = {
  introSub: 'Nuestro Propósito Coherente',
  introTitle: '¿Quiénes Somos en VOSERDEM?',
  introText: 'El Voluntariado de Servicio para el Desarrollo Humano y Medio Ambiente (VOSERDEM) es una institución boliviana guiada por profesionales y voluntarios de gran dedicación, profundamente comprometidos con la equidad social y la salud ecológica.',
  missionTitle: 'Nuestra Misión',
  missionText: 'Promover y consolidar el desarrollo integral del ser humano y la conservación del medio ambiente, capacitando a poblaciones marginadas mediante proyectos cooperativos, asistencia nutricional directa, agricultura ecológica y transferencia tecnológica participativa.',
  visionTitle: 'Nuestra Visión',
  visionText: 'Constituirnos en un modelo de referencia boliviano e internacional sobre desarrollo sostenible comunitario, donde la ecología regenerativa y la solidaridad intergeneracional se conjuguen para erradicar la extrema marginación de niños, jóvenes y adultos mayores.',
  imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=800',
  heroImageUrl: 'https://images.unsplash.com/photo-1469571486040-7a30d1de314a?auto=format&fit=crop&q=80&w=600',
  pillars: [
    {
      title: 'Desarrollo Humano Integral',
      description: 'Acompañamos a sectores en vulnerabilidad social en Cochabamba, proveyendo nutrición, educación popular, afecto, y capacitación laboral para fomentar autonomía.',
      iconName: 'Users'
    },
    {
      title: 'Restauración del Medio Ambiente',
      description: 'Llevamos adelante proyectos de reforestación nativa, permacultura y ecotecnologías en nuestro centro piloto "Ecocamp Chocaya", devolviendo salud al ecosistema.',
      iconName: 'Leaf'
    },
    {
      title: 'Dignidad para la Vejez',
      description: 'Nuestro programa estrella "Las Abuelitas" acoge a adultas mayores ofreciendo apoyo nutricional calórico ideal, controles sanitarios continuos y un hogar comunitario afectuoso.',
      iconName: 'Heart'
    },
    {
      title: 'Educación y Conciencia',
      description: 'Capacitamos de manera activa a escuelas públicas y delegados juveniles sobre conservación del agua, bio-construcción, abonos orgánicos e iniciativas de reciclaje.',
      iconName: 'GraduationCap'
    }
  ]
};

const initialCarouselSlides: CarouselSlide[] = [
  {
    id: 'slide-1',
    image: 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&q=80&w=1600',
    badge: 'Medio Ambiente & Ecología',
    badgeIconName: 'Trees',
    title: 'Sembrando Sostenibilidad, Cultivando Dignidad Humana',
    description: 'Somos una organización sin fines de lucro en Cochabamba, Bolivia. Restauramos ecosistemas degradados en el Ecocamp Chocaya y brindamos amor, nutrición y salud integral a nuestras queridas Abuelitas.'
  },
  {
    id: 'slide-2',
    image: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&q=80&w=1600',
    badge: 'Desarrollo Humano & Nutrición',
    badgeIconName: 'Users',
    title: 'Nutrición, Salud y Amor Incondicional para Abuelitas',
    description: 'Ofrecemos raciones alimentarias balanceadas, cuidado fisioterapéutico, acompañamiento espiritual y un espacio seguro de socialización para adultos mayores vulnerables en Cochabamba.'
  },
  {
    id: 'slide-3',
    image: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&q=80&w=1600',
    badge: 'Educación & Ecocamp Chocaya',
    badgeIconName: 'Landmark',
    title: 'Formación y Regeneración Ecológica Integrada',
    description: 'Transformamos la relación con nuestra Madre Tierra mediante capacitaciones en agroecología y reforestación nativa autónoma, capacitando a las nuevas generaciones de líderes ambientales.'
  },
  {
    id: 'slide-4',
    image: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?auto=format&fit=crop&q=80&w=1600',
    badge: 'Voluntariado Recíproco',
    badgeIconName: 'Heart',
    title: 'El Poder de Servir con el Corazón Abierto',
    description: 'Guiamos a voluntarios locales y extranjeros para canalizar sus profesiones y conocimientos directamente en áreas de salud, educación y restauración forestal boliviana.'
  },
  {
    id: 'slide-5',
    image: 'https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?auto=format&fit=crop&q=80&w=1600',
    badge: 'Proyectos Sostenibles',
    badgeIconName: 'Activity',
    title: 'Uniendo Esfuerzos para el Futuro de Bolivia',
    description: 'Desarrollamos tecnologías alternativas y huertos biointensivos que empoderan económicamente a familias vulnerables para lograr total soberanía ecológica alimentaria.'
  }
];

const initialLogoConfig: LogoConfig = {
  logoColor: {
    brandName: 'VOSERDEM',
    slogan: 'Voluntarios al Servicio de los Demás',
    useCustomImage: false,
    imageUrl: 'https://lh3.googleusercontent.com/d/1YZuC_fwe_Q8nVnH1tHzgts8tUbOKG_uX'
  },
  logoGold: {
    brandName: 'VOSERDEM',
    slogan: 'Unidos por Bolivia',
    useCustomImage: false,
    imageUrl: 'https://lh3.googleusercontent.com/d/1HCc3nOPUZMvvJOXnChQtij8F5NEbT0jn'
  }
};


function loadData(): DataStore {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(data) as DataStore;
      
      let updated = false;
      if (!parsed.projects) { parsed.projects = initialProjects; updated = true; }
      if (!parsed.donations) { parsed.donations = []; updated = true; }
      if (!parsed.messages) { parsed.messages = []; updated = true; }
      if (!parsed.blog) { parsed.blog = initialBlog; updated = true; }
      if (!parsed.bulletins) { parsed.bulletins = initialBulletins; updated = true; }
      if (!parsed.subscribers) { parsed.subscribers = []; updated = true; }
      if (!parsed.aboutUs) { parsed.aboutUs = initialAboutUs; updated = true; }
      if (!parsed.carouselSlides) { parsed.carouselSlides = initialCarouselSlides; updated = true; }
      if (!parsed.logoConfig) { parsed.logoConfig = initialLogoConfig; updated = true; }
      
      if (updated) {
        saveData(parsed);
      }
      return parsed;
    }
  } catch (err) {
    console.error('Error reading data-store file, using defaults:', err);
  }
  
  const defaultData: DataStore = {
    projects: initialProjects,
    donations: [],
    messages: [],
    blog: initialBlog,
    bulletins: initialBulletins,
    subscribers: [],
    aboutUs: initialAboutUs,
    carouselSlides: initialCarouselSlides,
    logoConfig: initialLogoConfig
  };
  saveData(defaultData);
  return defaultData;
}

function saveData(data: DataStore) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving to data-store file:', err);
  }
}

// ---------------------- API ROUTES ----------------------

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// CAROUSEL API
app.get('/api/carousel', (req, res) => {
  const data = loadData();
  res.json(data.carouselSlides || initialCarouselSlides);
});

app.put('/api/carousel', (req, res) => {
  const data = loadData();
  const slides = req.body;
  
  if (!Array.isArray(slides)) {
    return res.status(400).json({ error: 'El carrusel debe ser una lista de diapositivas.' });
  }

  if (slides.length > 5) {
    return res.status(400).json({ error: 'El carrusel debe contener un máximo de 5 fotografías/diapositivas.' });
  }

  // Sanitize slide images and update data
  data.carouselSlides = slides.map((slide: any) => ({
    id: slide.id || `slide-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    image: slide.image || 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&q=80&w=1600',
    badge: slide.badge || '',
    badgeIconName: slide.badgeIconName || 'Trees',
    title: slide.title || '',
    description: slide.description || ''
  }));

  saveData(data);
  res.json(data.carouselSlides);
});

// LOGOS API
app.get('/api/logos', (req, res) => {
  const data = loadData();
  res.json(data.logoConfig || initialLogoConfig);
});

app.put('/api/logos', (req, res) => {
  const data = loadData();
  const { logoColor, logoGold } = req.body;

  if (!logoColor || !logoGold) {
    return res.status(400).json({ error: 'Faltan configuraciones indispensables para guardar los logos.' });
  }

  data.logoConfig = {
    logoColor: {
      brandName: logoColor.brandName || "VOSERDEM",
      slogan: logoColor.slogan || "Voluntarios al Servicio de los Demás",
      useCustomImage: !!logoColor.useCustomImage,
      imageUrl: logoColor.imageUrl || ""
    },
    logoGold: {
      brandName: logoGold.brandName || "VOSERDEM",
      slogan: logoGold.slogan || "Unidos por Bolivia",
      useCustomImage: !!logoGold.useCustomImage,
      imageUrl: logoGold.imageUrl || ""
    }
  };

  saveData(data);
  res.json(data.logoConfig);
});

// ABOUT US API
app.get('/api/about', (req, res) => {
  const data = loadData();
  const about = data.aboutUs || initialAboutUs;
  if (!about.heroImageUrl) {
    about.heroImageUrl = initialAboutUs.heroImageUrl;
  }
  res.json(about);
});

app.put('/api/about', (req, res) => {
  const { introSub, introTitle, introText, missionTitle, missionText, visionTitle, visionText, imageUrl, heroImageUrl, pillars } = req.body;
  const data = loadData();
  
  data.aboutUs = {
    introSub: introSub || initialAboutUs.introSub,
    introTitle: introTitle || initialAboutUs.introTitle,
    introText: introText || initialAboutUs.introText,
    missionTitle: missionTitle || initialAboutUs.missionTitle,
    missionText: missionText || initialAboutUs.missionText,
    visionTitle: visionTitle || initialAboutUs.visionTitle,
    visionText: visionText || initialAboutUs.visionText,
    imageUrl: imageUrl || initialAboutUs.imageUrl,
    heroImageUrl: heroImageUrl || initialAboutUs.heroImageUrl,
    pillars: Array.isArray(pillars) ? pillars : initialAboutUs.pillars
  };
  
  saveData(data);
  res.json(data.aboutUs);
});

// PROJECTS API
// Get all projects
app.get('/api/projects', (req, res) => {
  const data = loadData();
  res.json(data.projects);
});

// Create a new project
app.post('/api/projects', (req, res) => {
  const { title, description, category, region, area, image, goal, location, impact, details } = req.body;
  if (!title || !description || !category || !goal) {
    return res.status(400).json({ error: 'Faltan campos obligatorios para el proyecto.' });
  }

  const data = loadData();
  const newProject: Project = {
    id: `proj-${Date.now()}`,
    title,
    description,
    category,
    region: region || 'Valles',
    area: area || 'Medio Ambiente',
    image: image || 'https://images.unsplash.com/photo-1469571486040-7a30d1de314a?auto=format&fit=crop&q=80&w=800',
    goal: Number(goal),
    raised: 0,
    location: location || 'Cochabamba, Bolivia',
    impact: impact || 'Ayudando a la comunidad local.',
    details: details || description
  };

  data.projects.push(newProject);
  saveData(data);

  res.status(201).json(newProject);
});

// Update a project
app.put('/api/projects/:id', (req, res) => {
  const { id } = req.params;
  const { title, description, category, region, area, image, goal, raised, location, impact, details } = req.body;

  const data = loadData();
  const index = data.projects.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Proyecto no encontrado.' });
  }

  const updatedProject = {
    ...data.projects[index],
    title: title !== undefined ? title : data.projects[index].title,
    description: description !== undefined ? description : data.projects[index].description,
    category: category !== undefined ? category : data.projects[index].category,
    region: region !== undefined ? region : data.projects[index].region,
    area: area !== undefined ? area : data.projects[index].area,
    image: image !== undefined ? image : data.projects[index].image,
    goal: goal !== undefined ? Number(goal) : data.projects[index].goal,
    raised: raised !== undefined ? Number(raised) : data.projects[index].raised,
    location: location !== undefined ? location : data.projects[index].location,
    impact: impact !== undefined ? impact : data.projects[index].impact,
    details: details !== undefined ? details : data.projects[index].details,
  };

  data.projects[index] = updatedProject;
  saveData(data);

  res.json(updatedProject);
});

// Delete a project
app.delete('/api/projects/:id', (req, res) => {
  const { id } = req.params;
  const data = loadData();
  const index = data.projects.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Proyecto no encontrado.' });
  }

  data.projects.splice(index, 1);
  saveData(data);

  res.json({ success: true, message: 'Proyecto eliminado con éxito.' });
});


// DONATIONS API
// Support a project
app.post('/api/donations', (req, res) => {
  const { donorName, email, amount, projectId, comment } = req.body;
  if (!donorName || !email || !amount || !projectId) {
    return res.status(400).json({ error: 'Faltan campos obligatorios para registrar la donación.' });
  }

  const data = loadData();
  const projectIndex = data.projects.findIndex(p => p.id === projectId);
  if (projectIndex === -1) {
    return res.status(404).json({ error: 'Proyecto destinatario no existe.' });
  }

  const amountNum = Number(amount);
  if (isNaN(amountNum) || amountNum <= 0) {
    return res.status(400).json({ error: 'El monto de la donación debe ser un número positivo.' });
  }

  // Update projects raised amount
  data.projects[projectIndex].raised += amountNum;

  // Add donation log
  const newDonation: Donation = {
    id: `don-${Date.now()}`,
    donorName,
    email,
    amount: amountNum,
    projectId,
    projectTitle: data.projects[projectIndex].title,
    date: new Date().toISOString(),
    comment
  };

  data.donations.push(newDonation);
  saveData(data);

  res.status(201).json({ success: true, donation: newDonation, currentRaised: data.projects[projectIndex].raised });
});

// Get all donations
app.get('/api/donations', (req, res) => {
  const data = loadData();
  res.json(data.donations);
});


// CONTACT MESSAGES API
// Submit a message
app.post('/api/messages', (req, res) => {
  const { name, email, subject, message } = req.body;
  if (!name || !email || !subject || !message) {
    return res.status(400).json({ error: 'Por favor, rellene todos los campos de mensaje.' });
  }

  const data = loadData();
  const newMessage: Message = {
    id: `msg-${Date.now()}`,
    name,
    email,
    subject,
    message,
    date: new Date().toISOString()
  };

  data.messages.push(newMessage);
  saveData(data);

  res.status(201).json({ success: true, message: newMessage });
});

// Get all messages
app.get('/api/messages', (req, res) => {
  const data = loadData();
  res.json(data.messages);
});


// --- BLOG API ---
// Get all posts
app.get('/api/blog', (req, res) => {
  const data = loadData();
  const showAll = req.query.all === 'true' || req.query.status === 'all';
  if (showAll) {
    res.json(data.blog || []);
  } else {
    const published = (data.blog || []).filter(b => b.status !== 'draft');
    res.json(published);
  }
});

// Create a blog post
app.post('/api/blog', (req, res) => {
  const { title, summary, content, image, category, author, readTime, featured, status } = req.body;
  if (!title || !content || !category || !author) {
    return res.status(400).json({ error: 'Faltan campos obligatorios para el artículo del blog.' });
  }

  const data = loadData();
  const newPost: BlogPost = {
    id: `blog-${Date.now()}`,
    title,
    summary: summary || content.slice(0, 150) + '...',
    content,
    image: image || 'https://images.unsplash.com/photo-1469571486040-7a30d1de314a?auto=format&fit=crop&q=80&w=800',
    category,
    author,
    date: new Date().toISOString().split('T')[0],
    readTime: readTime || '3 min',
    featured: !!featured,
    status: status || 'published'
  };

  data.blog.push(newPost);
  saveData(data);
  res.status(201).json(newPost);
});

// Update a blog post
app.put('/api/blog/:id', (req, res) => {
  const { id } = req.params;
  const { title, summary, content, image, category, author, readTime, featured, status } = req.body;

  const data = loadData();
  const index = data.blog.findIndex(b => b.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Artículo no encontrado.' });
  }

  data.blog[index] = {
    ...data.blog[index],
    title: title !== undefined ? title : data.blog[index].title,
    summary: summary !== undefined ? summary : data.blog[index].summary,
    content: content !== undefined ? content : data.blog[index].content,
    image: image !== undefined ? image : data.blog[index].image,
    category: category !== undefined ? category : data.blog[index].category,
    author: author !== undefined ? author : data.blog[index].author,
    readTime: readTime !== undefined ? readTime : data.blog[index].readTime,
    featured: featured !== undefined ? !!featured : data.blog[index].featured,
    status: status !== undefined ? status : data.blog[index].status
  };

  saveData(data);
  res.json(data.blog[index]);
});

// Delete a blog post
app.delete('/api/blog/:id', (req, res) => {
  const { id } = req.params;
  const data = loadData();
  const index = data.blog.findIndex(b => b.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Artículo no encontrado.' });
  }

  data.blog.splice(index, 1);
  saveData(data);
  res.json({ success: true, message: 'Artículo eliminado con éxito.' });
});


// --- BULLETINS (BOLETINES) API ---
// Get all bulletins
app.get('/api/bulletins', (req, res) => {
  const data = loadData();
  const showAll = req.query.all === 'true' || req.query.status === 'all';
  if (showAll) {
    res.json(data.bulletins || []);
  } else {
    const published = (data.bulletins || []).filter(b => b.status !== 'draft');
    res.json(published);
  }
});

// Create a bulletin
app.post('/api/bulletins', (req, res) => {
  const { title, summary, issueNumber, downloadUrl, image, status } = req.body;
  if (!title || !summary || !issueNumber) {
    return res.status(400).json({ error: 'Faltan campos obligatorios para el boletín.' });
  }

  const data = loadData();
  const newBulletin: Bulletin = {
    id: `bull-${Date.now()}`,
    title,
    summary,
    issueNumber,
    publishDate: new Date().toISOString().split('T')[0],
    downloadUrl: downloadUrl || 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    image: image || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=800',
    status: status || 'published'
  };

  data.bulletins.push(newBulletin);
  saveData(data);
  res.status(201).json(newBulletin);
});

// Update a bulletin
app.put('/api/bulletins/:id', (req, res) => {
  const { id } = req.params;
  const { title, summary, issueNumber, downloadUrl, image, status } = req.body;

  const data = loadData();
  const index = data.bulletins.findIndex(b => b.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Boletín no encontrado.' });
  }

  data.bulletins[index] = {
    ...data.bulletins[index],
    title: title !== undefined ? title : data.bulletins[index].title,
    summary: summary !== undefined ? summary : data.bulletins[index].summary,
    issueNumber: issueNumber !== undefined ? issueNumber : data.bulletins[index].issueNumber,
    downloadUrl: downloadUrl !== undefined ? downloadUrl : data.bulletins[index].downloadUrl,
    image: image !== undefined ? image : data.bulletins[index].image,
    status: status !== undefined ? status : data.bulletins[index].status
  };

  saveData(data);
  res.json(data.bulletins[index]);
});

// Delete a bulletin
app.delete('/api/bulletins/:id', (req, res) => {
  const { id } = req.params;
  const data = loadData();
  const index = data.bulletins.findIndex(b => b.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Boletín no encontrado.' });
  }

  data.bulletins.splice(index, 1);
  saveData(data);
  res.json({ success: true, message: 'Boletín eliminado con éxito.' });
});


// --- NEWSLETTER SUBSCRIBERS ---
// Get all newsletter subscribers
app.get('/api/subscribers', (req, res) => {
  const data = loadData();
  res.json(data.subscribers || []);
});

// Subscribe to newsletter
app.post('/api/subscribers', (req, res) => {
  const { email } = req.body;
  if (!email || !email.includes('@')) {
    return res.status(400).json({ error: 'Dirección de correo electrónico inválida.' });
  }

  const data = loadData();
  const exists = data.subscribers.some(s => s.email.toLowerCase() === email.toLowerCase());
  if (exists) {
    return res.status(400).json({ error: 'Este correo ya se encuentra registrado en nuestro boletín informativo.' });
  }

  const newSubscriber: Subscriber = {
    id: `sub-${Date.now()}`,
    email: email.trim(),
    date: new Date().toISOString()
  };

  data.subscribers.push(newSubscriber);
  saveData(data);
  res.status(201).json({ success: true, subscriber: newSubscriber });
});

// Unsubscribe
app.delete('/api/subscribers/:id', (req, res) => {
  const { id } = req.params;
  const data = loadData();
  const index = data.subscribers.findIndex(s => s.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Suscriptor no encontrado.' });
  }

  data.subscribers.splice(index, 1);
  saveData(data);
  res.json({ success: true, message: 'Suscripción cancelada con éxito.' });
});


// Reset data (Admin utility)
app.post('/api/admin/reset', (req, res) => {
  const defaultData: DataStore = {
    projects: initialProjects,
    donations: [],
    messages: [],
    blog: initialBlog,
    bulletins: initialBulletins,
    subscribers: [],
    aboutUs: initialAboutUs,
    carouselSlides: initialCarouselSlides,
    logoConfig: initialLogoConfig
  };
  saveData(defaultData);
  res.json({ success: true, message: 'Base de datos restaurada a valores predeterminados.' });
});

// ---------------------- VITE / MIDDLEWARE SETUP ----------------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
